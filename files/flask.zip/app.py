# dependencies
from flask import (Flask, render_template, jsonify, url_for )
import pandas as pd 
from sqlalchemy import create_engine, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.ext.automap import automap_base
from sqlalchemy import Column, Integer, String, Numeric, Text, Float, Date
import os


# initialize database
db_uri = os.getenv("DATABASE_URI", "sqlite:///project2.sqlite") 
engine = create_engine( db_uri )

# read data from project 2 and save to sqlite
gh = pd.read_csv("DataSets/Main_data_AppendixG.csv")


#Cleanup
#removed percentage signs, removed † and replace with NaN, format cells as float
gh['Low-Income 2015\nACGR(%)'] = gh['Low-Income 2015\nACGR(%)'].str.replace('%','').astype(float)
gh['Estimated \nNon-Low-Income 2015 ACGR(%)'] = gh['Estimated \nNon-Low-Income 2015 ACGR(%)'].str.replace('%','').astype(float)
gh['Gap Change between Non-Low-Income\n and Low-Income ACGR\n(Percentage points), 2011-15'] = gh['Gap Change between Non-Low-Income\n and Low-Income ACGR\n(Percentage points), 2011-15'].str.replace('†','NaN').astype(float)
gh['Overall 2015 \nACGR(%)'] = gh['Overall 2015 \nACGR(%)'].str.replace('%','').astype(float)

# drop the last column showing NaN since its not a state
gh = gh.drop(gh.index[len(gh)-1])

# rename column headers so they have no spaces
gh.columns = [ 'abb', 'state', 'gap_between_low_and_nonlow_income_2011', 'overall_2015', 'percent_lowincome_2015', \
'estimated_non_low_2015', 'low_income_2015','gap_between_nonlow_lowincome_2015', 'gap_change_2011-15']


# save to database
gh.to_sql('graduation', engine, if_exists='replace')

app = Flask(__name__)

@app.route("/")
def home():
    conn = engine.connect() 
    query = 'select state from graduation'
    results = conn.execute( query ).fetchall()
    states = [ i['state'] for i in results ] 

    return render_template("index.html", states=states )

@app.route("/data")
def me():
    # query data from the database return it as json
    conn = engine.connect() 
    query = 'select abb, low_income_2015 from graduation'
    results = conn.execute( query ).fetchall()
    name = [ i['abb'] for i in results]
    income = [ i['low_income_2015'] for i in results ]

    data = {}
    for i,j in zip( name, income  ):
        data[i] = j

    return jsonify( data )

@app.route("/state/<state>")
def state(state):

    conn = engine.connect() 
    query = "SELECT * FROM graduation WHERE state = '{}'".format(state)
    results = conn.execute( query ).fetchone()
    
    data = {} 
    names = results.keys() 

    for i,j in zip( names, results ):
        data[i] = j

    return jsonify( data )

if __name__ == "__main__": 
    app.run(debug=True)


    
