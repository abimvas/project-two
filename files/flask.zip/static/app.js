data_url = '/data'
Plotly.d3.json(data_url, function(error, response) {

    if (error) return console.warn(error);


    var names = [];
    var income = [];
    // Grab values from the response json object to build the plots
    for ( var i in response ) {

        names.push(i);
        income.push(response[i]);
    }

    var data = [
        {
          x: names,
          y: income,
          type: 'bar'
        }
      ];
      
      Plotly.newPlot('myDiv', data);
   console.log(income)
   console.log(names)
 });